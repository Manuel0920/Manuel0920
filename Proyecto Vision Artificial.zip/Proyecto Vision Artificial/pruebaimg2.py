import cv2

cap = cv2.VideoCapture(1)

mi11 = cv2.CascadeClassifier('Note12Pro.xml')

while True:
    ret, frame = cap.read()
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    objects = mi11.detectMultiScale(gray,
                                    scaleFactor=5,
                                    minNeighbors=800,
                                    minSize=(70, 80))

    for (x, y, w, h) in objects:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (109, 191, 209), 2)
        cv2.putText(frame, 'Xiaomi Note 12 Pro', (x, y-10), 2, 0.7, (109, 191, 209), 2, cv2.LINE_AA)

    cv2.imshow('identificar_objeto', frame)

    if cv2.waitKey(1) == 27:
        break

cap.release()
cv2.destroyAllWindows()
