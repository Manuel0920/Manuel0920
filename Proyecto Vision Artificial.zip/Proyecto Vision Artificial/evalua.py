import cv2

cap = cv2.VideoCapture(1)

note9 = cv2.CascadeClassifier('Note9pro.xml')
note11 = cv2.CascadeClassifier('Note11.xml')
note12= cv2.CascadeClassifier('Note12Pro.xml')
pocom3 = cv2.CascadeClassifier('Pocom3.xml')
pocom4 = cv2.CascadeClassifier('Pocom4.xml')
pocox3 = cv2.CascadeClassifier('pocox3.xml')

while True:

    ret,frame = cap.read()
    frame2 = frame;
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    note_9 = note9.detectMultiScale(gray,
            scaleFactor = 5,
	        minNeighbors = 800,
	        minSize=(70,80))

    note_11 = note11.detectMultiScale(gray,
            scaleFactor = 5,
	        minNeighbors = 800,
	        minSize=(70,80))

    note_12 = note12.detectMultiScale(gray,
            scaleFactor = 5,
	        minNeighbors = 800,
	        minSize=(70,80))

    poco_m3 = pocom3.detectMultiScale(gray,
            scaleFactor = 5,
	        minNeighbors = 800,
	        minSize=(70,80))

    poco_m4 = pocom4.detectMultiScale(gray,
            scaleFactor = 5,
	        minNeighbors = 800,
	        minSize=(70,80))
    
    poco_x3 = pocox3.detectMultiScale(gray,
            scaleFactor = 5,
	        minNeighbors = 800,
	        minSize=(70,80))

    for (x,y,w,h) in note_9:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 1, 0), 2)
        cv2.putText(frame, 'Redmi Note 9 Pro', (x, y-10), 2, 0.7, (0, 1, 0), 2, cv2.LINE_AA)


    for (x,y,w,h) in note_11:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (1, 1, 1), 2)
        cv2.putText(frame, 'Redmi Note 11', (x, y-10), 2, 0.7, (1, 1, 1), 2, cv2.LINE_AA)


    for (x,y,w,h) in note_12:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 0, 0), 2)
        cv2.putText(frame, 'Redmi Note 12 Pro', (x, y-10), 2, 0.7, (0, 0, 0), 2, cv2.LINE_AA)


    for (x,y,w,h) in poco_m3:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (1, 0, 0), 2)
        cv2.putText(frame, 'Pocophone M3', (x, y-10), 2, 0.7, (1, 0, 0), 2, cv2.LINE_AA)

    for (x,y,w,h) in poco_m4:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 0, 0.9), 2)
        cv2.putText(frame, 'Pocophone M4', (x, y-10), 2, 0.7, (0, 0, 0.9), 2, cv2.LINE_AA)

    for (x,y,w,h) in poco_x3:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0,0.8,0.9), 2)
        cv2.putText(frame, 'Poco X3', (x, y-10), 2, 0.7, (0, 0.8, 0.9), 2, cv2.LINE_AA)
    

    cv2.imshow('identificar_objeto',frame)

    if cv2.waitKey(1) == 27:
        break
    

cap.release()
cv2.destroyAllWindows()